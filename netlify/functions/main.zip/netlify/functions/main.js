var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var main_exports = {};
__export(main_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(main_exports);
var import_mongodb = require("../../src/utils/mongodb.js");
function createResponse(data, status = 200, headers = {}) {
  const defaultHeaders = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization"
  };
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...defaultHeaders, ...headers }
  });
}
function createErrorResponse(error, status = 500) {
  return createResponse({
    success: false,
    error: error.message || "Internal Server Error",
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  }, status);
}
function handlePreflight() {
  return new Response(null, {
    status: 204,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Max-Age": "86400"
    }
  });
}
async function handleTest(request, env) {
  try {
    const url = new URL(request.url);
    const detailed = url.searchParams.get("detailed") === "true";
    const mongoHealth = await (0, import_mongodb.checkMongoHealth)(env);
    const response = {
      success: mongoHealth.ok,
      message: mongoHealth.ok ? "\u670D\u52A1\u5668\u8FD0\u884C\u6B63\u5E38" : "\u670D\u52A1\u5668\u8FDE\u63A5\u5F02\u5E38",
      service: "donation-collection-system",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      mongodb: {
        connected: mongoHealth.ok,
        message: mongoHealth.message
      }
    };
    return createResponse(response);
  } catch (error) {
    console.error("Test API error:", error);
    return createErrorResponse(error);
  }
}
async function handleDonations(request, env, path) {
  const method = request.method.toUpperCase();
  try {
    switch (method) {
      case "GET":
        return await getDonations(request, env);
      case "POST":
        return await postDonations(request, env);
      case "DELETE":
        return await deleteDonation(request, env, path);
      default:
        return createResponse(
          { success: false, error: "Method Not Allowed" },
          405
        );
    }
  } catch (error) {
    console.error("Donations API error:", error);
    return createErrorResponse(error);
  }
}
async function getDonations(request, env) {
  const collection = await (0, import_mongodb.getDonationCollection)(env);
  const url = new URL(request.url);
  const params = url.searchParams;
  const query = buildQuery(params);
  const page = Math.max(1, parseInt(params.get("page") || "1"));
  const limit = Math.min(100, Math.max(1, parseInt(params.get("limit") || "50")));
  const skip = (page - 1) * limit;
  const sortField = params.get("sortBy") || "submittedAt";
  const sortOrder = params.get("sortOrder") === "asc" ? 1 : -1;
  const sort = { [sortField]: sortOrder };
  const [data, total] = await Promise.all([
    collection.find(query).sort(sort).skip(skip).limit(limit).toArray(),
    collection.countDocuments(query)
  ]);
  const formattedData = data.map((item) => ({
    ...item,
    _id: item._id.toString(),
    submittedAt: item.submittedAt?.toISOString(),
    createdAt: item.createdAt?.toISOString(),
    updatedAt: item.updatedAt?.toISOString()
  }));
  return createResponse({
    success: true,
    data: formattedData,
    pagination: {
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
      hasNext: page * limit < total,
      hasPrev: page > 1
    }
  });
}
async function postDonations(request, env) {
  const collection = await (0, import_mongodb.getDonationCollection)(env);
  const body = await request.json();
  if (!body.name || !body.name.trim()) {
    return createResponse(
      { success: false, error: "\u59D3\u540D\u4E3A\u5FC5\u586B\u9879" },
      400
    );
  }
  if (!body.project || !body.project.trim()) {
    return createResponse(
      { success: false, error: "\u62A4\u6301\u9879\u76EE\u4E3A\u5FC5\u586B\u9879" },
      400
    );
  }
  if (body.data && Array.isArray(body.data)) {
    return await handleBatchInsert(body.data, collection);
  }
  const donationData = createDonationData(body);
  const result = await collection.insertOne(donationData);
  return createResponse({
    success: true,
    message: "\u6570\u636E\u4FDD\u5B58\u6210\u529F",
    id: result.insertedId.toString(),
    data: {
      ...donationData,
      _id: result.insertedId.toString()
    }
  });
}
async function deleteDonation(request, env, path) {
  const collection = await (0, import_mongodb.getDonationCollection)(env);
  const url = new URL(request.url);
  const id = extractIdFromPath(path);
  if (!id) {
    return createResponse(
      { success: false, error: "\u672A\u6307\u5B9A\u8981\u5220\u9664\u7684\u8BB0\u5F55ID" },
      400
    );
  }
  const adminPassword = url.searchParams.get("adminPassword");
  const expectedPassword = env.ADMIN_PASSWORD;
  if (!adminPassword || adminPassword !== expectedPassword) {
    return createResponse(
      { success: false, error: "\u7BA1\u7406\u5458\u5BC6\u7801\u9519\u8BEF\u6216\u672A\u63D0\u4F9B" },
      401
    );
  }
  let query;
  if ((0, import_mongodb.isValidObjectId)(id)) {
    query = { _id: id };
  } else {
    query = {
      $or: [
        { localId: id },
        { serverId: id },
        { deviceId: id }
      ]
    };
  }
  const result = await collection.deleteOne(query);
  return createResponse({
    success: result.deletedCount > 0,
    deletedCount: result.deletedCount,
    message: result.deletedCount > 0 ? "\u5220\u9664\u6210\u529F" : "\u672A\u627E\u5230\u8BB0\u5F55"
  });
}
function buildQuery(params) {
  const query = {};
  const search = params.get("search");
  if (search && search.trim()) {
    query.$text = { $search: search.trim() };
  }
  const project = params.get("project");
  if (project && project.trim()) {
    query.project = project.trim();
  }
  const payment = params.get("payment");
  if (payment && payment.trim()) {
    query.payment = payment.trim();
  }
  const startDate = params.get("startDate");
  const endDate = params.get("endDate");
  if (startDate || endDate) {
    query.submittedAt = {};
    if (startDate) {
      query.submittedAt.$gte = /* @__PURE__ */ new Date(`${startDate}T00:00:00.000Z`);
    }
    if (endDate) {
      query.submittedAt.$lte = /* @__PURE__ */ new Date(`${endDate}T23:59:59.999Z`);
    }
  }
  return query;
}
function createDonationData(body) {
  const now = /* @__PURE__ */ new Date();
  return {
    name: body.name.trim(),
    project: body.project,
    method: body.method || "",
    amountTWD: parseFloat(body.amountTWD) || 0,
    amountRMB: parseFloat(body.amountRMB) || 0,
    content: body.content || "",
    payment: body.payment || "\u672A\u7F34\u8D39",
    contact: body.contact || "",
    deviceId: body.deviceId || "",
    batchId: body.batchId || "",
    localId: body.localId || generateLocalId(),
    submittedAt: body.submittedAt ? new Date(body.submittedAt) : now,
    createdAt: now,
    updatedAt: now
  };
}
async function handleBatchInsert(data, collection) {
  const donations = data.map((item) => createDonationData(item));
  const validDonations = donations.filter((d) => d.name && d.project);
  if (validDonations.length === 0) {
    return createResponse(
      { success: false, error: "\u6CA1\u6709\u6709\u6548\u7684\u6350\u8D60\u6570\u636E" },
      400
    );
  }
  const result = await collection.insertMany(validDonations);
  return createResponse({
    success: true,
    message: `\u6210\u529F\u63D2\u5165 ${result.insertedCount} \u6761\u8BB0\u5F55`,
    insertedCount: result.insertedCount,
    insertedIds: Object.values(result.insertedIds).map((id) => id.toString())
  });
}
function extractIdFromPath(path) {
  const parts = path.split("/");
  const id = parts[parts.length - 1];
  return id && id !== "donations" ? id : null;
}
function generateLocalId() {
  return `local_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}
async function handler(event, context) {
  const { path, httpMethod, headers, body } = event;
  const url = new URL(`http://${headers.host}${path}`);
  const request = new Request(url, {
    method: httpMethod,
    headers,
    body: httpMethod === "POST" || httpMethod === "PUT" ? body : void 0
  });
  const env = process.env;
  console.log(`[${(/* @__PURE__ */ new Date()).toISOString()}] ${httpMethod} ${path}`);
  if (httpMethod === "OPTIONS") {
    return handlePreflight();
  }
  try {
    let response;
    switch (true) {
      case (path === "/api/test" || path === "/api/test/"):
        response = await handleTest(request, env);
        break;
      case (path === "/api/donations" || path.startsWith("/api/donations/")):
        response = await handleDonations(request, env, path);
        break;
      case (path === "/health" || path === "/health/"):
        const mongoHealth = await (0, import_mongodb.checkMongoHealth)(env);
        response = createResponse({
          status: "ok",
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          service: "donation-collection-system",
          mongodb: {
            connected: mongoHealth.ok,
            message: mongoHealth.message
          }
        });
        break;
      default:
        response = createResponse({
          success: false,
          error: "Not Found",
          path,
          availableEndpoints: [
            "/api/test",
            "/api/donations",
            "/health"
          ]
        }, 404);
    }
    return response;
  } catch (error) {
    console.error("Global error handler:", error);
    return createErrorResponse(error, 500);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
