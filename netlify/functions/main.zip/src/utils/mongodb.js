var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var mongodb_exports = {};
__export(mongodb_exports, {
  checkMongoHealth: () => checkMongoHealth,
  closeMongoConnection: () => closeMongoConnection,
  getDatabase: () => getDatabase,
  getDonationCollection: () => getDonationCollection,
  getMongoClient: () => getMongoClient,
  isValidObjectId: () => isValidObjectId
});
module.exports = __toCommonJS(mongodb_exports);
var import_mongodb = require("mongodb");
let cachedClient = null;
let cachedDb = null;
async function getMongoClient(env) {
  if (cachedClient && cachedClient.topology?.isConnected()) {
    return cachedClient;
  }
  try {
    const MONGODB_URI = env.MONGODB_URI;
    if (!MONGODB_URI) {
      throw new Error("MONGODB_URI environment variable is required");
    }
    const client = new import_mongodb.MongoClient(MONGODB_URI, {
      maxPoolSize: 5,
      minPoolSize: 1,
      maxIdleTimeMS: 3e4,
      connectTimeoutMS: 1e4,
      socketTimeoutMS: 45e3,
      serverSelectionTimeoutMS: 1e4,
      retryWrites: true,
      w: "majority"
    });
    await client.connect();
    console.log("MongoDB connected successfully");
    await client.db().admin().ping();
    cachedClient = client;
    return client;
  } catch (error) {
    console.error("Failed to connect to MongoDB:", error);
    cachedClient = null;
    throw error;
  }
}
async function getDatabase(env) {
  try {
    const client = await getMongoClient(env);
    const dbName = env.DATABASE_NAME || "donation_system";
    if (!cachedDb) {
      cachedDb = client.db(dbName);
    }
    return cachedDb;
  } catch (error) {
    console.error("Failed to get database:", error);
    throw error;
  }
}
async function getDonationCollection(env) {
  try {
    const db = await getDatabase(env);
    const collectionName = env.COLLECTION_NAME || "donations";
    const collections = await db.listCollections({ name: collectionName }).toArray();
    if (collections.length === 0) {
      console.log(`Creating collection: ${collectionName}`);
      await db.createCollection(collectionName);
      const collection = db.collection(collectionName);
      await createIndexes(collection);
    }
    return db.collection(collectionName);
  } catch (error) {
    console.error("Failed to get collection:", error);
    throw error;
  }
}
async function createIndexes(collection) {
  try {
    await collection.createIndex({ submittedAt: -1 });
    await collection.createIndex({ name: 1 });
    await collection.createIndex({ project: 1 });
    await collection.createIndex({ payment: 1 });
    await collection.createIndex({ localId: 1 }, { unique: true, sparse: true });
    await collection.createIndex({ deviceId: 1 });
    await collection.createIndex({ batchId: 1 });
    await collection.createIndex(
      { name: "text", project: "text", content: "text", contact: "text" },
      { weights: { name: 10, project: 5, content: 3, contact: 2 } }
    );
    console.log("Collection indexes created successfully");
  } catch (error) {
    console.warn("Failed to create indexes:", error.message);
  }
}
function isValidObjectId(id) {
  return typeof id === "string" && /^[0-9a-fA-F]{24}$/.test(id);
}
async function closeMongoConnection() {
  if (cachedClient) {
    try {
      await cachedClient.close();
      console.log("MongoDB connection closed");
    } catch (error) {
      console.error("Error closing MongoDB connection:", error);
    } finally {
      cachedClient = null;
      cachedDb = null;
    }
  }
}
async function checkMongoHealth(env) {
  try {
    const client = await getMongoClient(env);
    await client.db().admin().ping();
    return { ok: true, message: "MongoDB is connected" };
  } catch (error) {
    return { ok: false, message: `MongoDB connection failed: ${error.message}` };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  checkMongoHealth,
  closeMongoConnection,
  getDatabase,
  getDonationCollection,
  getMongoClient,
  isValidObjectId
});
